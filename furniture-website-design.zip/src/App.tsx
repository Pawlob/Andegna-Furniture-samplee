/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import gsap from 'gsap';
import CircularGallery from './CircularGallery';
import CardNav from './CardNav';

const translations = {
  en: {
    gallery: [
      { image: `https://i.postimg.cc/mgJPs2Fr/410555648-21ead13a-cb97-4f1c-a1e7-8704f360135d.png`, text: 'Bridge', description: 'A structural marvel crossing the waters, connecting two distinct landscapes.', color: '#1e293b' },
      { image: `https://i.postimg.cc/76yMqNTP/320731638-11288297-(1).png`, text: 'Desk Setup', description: 'A clean, minimal workspace designed for focus and productivity.', color: '#3f2723', bgImage: 'https://i.postimg.cc/Gh40wyFM/Gemini-Generated-Image-9i9o939i9o939i9o.png' },
      { image: `https://i.postimg.cc/pL5PHQHS/409092845-a2ff2545-4a06-44aa-aad6-d165ce7ece0f.png`, text: 'Waterfall', description: 'Nature’s raw power cascading down the rocky cliffs.', color: '#0f3a3a', bgImage: 'https://i.postimg.cc/Y0S4R3mm/Watermark-Free-Interior.png' },
      { image: `https://i.postimg.cc/L6t8YB7M/358181730-11444651-(1).png`, text: 'Strawberries', description: 'Fresh, vibrant, and sweet summer fruits.', color: '#4a1525', bgImage: 'https://i.postimg.cc/28vh3HrR/Dark-Wall-Living-Room.png' },
      { image: `https://i.postimg.cc/Hs6s9spK/412670393-fbcb5734-2019-4045-9a34-6c17c4a3741e-(1).png`, text: 'Deep Diving', description: 'Exploring the serene and mysterious underwater world.', color: '#0f172a' }
    ],
    nav: [
      {
        label: "About",
        bgColor: "#0D0716",
        textColor: "#fff",
        links: [
          { label: "Company", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "About Company" },
          { label: "Careers", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "About Careers" }
        ]
      },
      {
        label: "Projects", 
        bgColor: "#170D27",
        textColor: "#fff",
        links: [
          { label: "Featured", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "Featured Projects" },
          { label: "Case Studies", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "Project Case Studies" }
        ]
      },
      {
        label: "Contact",
        bgColor: "#271E37", 
        textColor: "#fff",
        links: [
          { label: "Email", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "Email us" },
          { label: "Twitter", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "Twitter" },
          { label: "LinkedIn", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "LinkedIn" }
        ]
      }
    ],
    cta: "Get Started"
  },
  am: {
    gallery: [
      { image: `https://i.postimg.cc/mgJPs2Fr/410555648-21ead13a-cb97-4f1c-a1e7-8704f360135d.png`, text: 'ድልድይ', description: 'ውሃዎችን የሚያቋርጥ እና ሁለት የተለያዩ የመሬት ገጽታዎችን የሚያገናኝ መዋቅራዊ ድንቅ።', color: '#1e293b' },
      { image: `https://i.postimg.cc/76yMqNTP/320731638-11288297-(1).png`, text: 'የጠረጴዛ ዝግጅት', description: 'ለትኩረት እና ለምርታማነት የተነደፈ ንጹህ እና አነስተኛ የስራ ቦታ።', color: '#3f2723', bgImage: 'https://i.postimg.cc/Gh40wyFM/Gemini-Generated-Image-9i9o939i9o939i9o.png' },
      { image: `https://i.postimg.cc/pL5PHQHS/409092845-a2ff2545-4a06-44aa-aad6-d165ce7ece0f.png`, text: 'ፏፏቴ', description: 'የተፈጥሮ ጥሬ ሃይል በዓለታማ ገደሎች ላይ ሲወርድ።', color: '#0f3a3a', bgImage: 'https://i.postimg.cc/Y0S4R3mm/Watermark-Free-Interior.png' },
      { image: `https://i.postimg.cc/L6t8YB7M/358181730-11444651-(1).png`, text: 'እንጆሪ', description: 'ትኩስ፣ ደማቅ እና ጣፋጭ የበጋ ፍራፍሬዎች።', color: '#4a1525', bgImage: 'https://i.postimg.cc/28vh3HrR/Dark-Wall-Living-Room.png' },
      { image: `https://i.postimg.cc/Hs6s9spK/412670393-fbcb5734-2019-4045-9a34-6c17c4a3741e-(1).png`, text: 'ጥልቅ ዳይቪንግ', description: 'ጸጥ ያለውን እና ሚስጥራዊውን የውሃ ውስጥ ዓለም ማሰስ።', color: '#0f172a' }
    ],
    nav: [
      {
        label: "ስለ እኛ",
        bgColor: "#0D0716",
        textColor: "#fff",
        links: [
          { label: "ኩባንያ", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "ስለ ኩባንያ" },
          { label: "ስራዎች", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "ስለ ስራዎች" }
        ]
      },
      {
        label: "ፕሮጀክቶች", 
        bgColor: "#170D27",
        textColor: "#fff",
        links: [
          { label: "ተለይተው የቀረቡ", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "ተለይተው የቀረቡ ፕሮጀክቶች" },
          { label: "የጉዳይ ጥናቶች", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "የፕሮጀክት የጉዳይ ጥናቶች" }
        ]
      },
      {
        label: "አድራሻ",
        bgColor: "#271E37", 
        textColor: "#fff",
        links: [
          { label: "ኢሜይል", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "ኢሜይል ይላኩልን" },
          { label: "ትዊተር", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "ትዊተር" },
          { label: "ሊንክድኢን", href: "https://pawlos-mulugeta-portfolio.vercel.app/", ariaLabel: "ሊንክድኢን" }
        ]
      }
    ],
    cta: "ይጀምሩ"
  }
};

type Language = 'en' | 'am';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [activeIndex, setActiveIndex] = useState(0);
  const [displayIndex, setDisplayIndex] = useState(0);
  
  const t = translations[lang];
  const activeItem = t.gallery[activeIndex];
  const displayItem = t.gallery[displayIndex];
  const containerRef = useRef<HTMLDivElement>(null);

  const toggleLanguage = () => {
    setLang(prev => prev === 'en' ? 'am' : 'en');
  };

  useEffect(() => {
    if (activeIndex === displayIndex) return;

    let isCancelled = false;

    const ctx = gsap.context(() => {
      gsap.to('.reveal-text', {
        y: '-100%',
        duration: 0.4,
        stagger: 0.05,
        ease: 'power3.in',
        onComplete: () => {
          if (!isCancelled) {
            setDisplayIndex(activeIndex);
          }
        }
      });
    }, containerRef);

    return () => {
      isCancelled = true;
      ctx.revert();
    };
  }, [activeIndex, displayIndex]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.reveal-text',
        { y: '100%' },
        { y: '0%', duration: 0.6, stagger: 0.1, ease: 'power3.out' }
      );
    }, containerRef);
    return () => ctx.revert();
  }, [displayIndex]);

  return (
    <motion.div 
      className="w-full min-h-screen flex flex-col md:flex-row items-center justify-between overflow-hidden transition-colors duration-700 ease-in-out relative"
      style={{ backgroundColor: activeItem.color }}
    >
      <AnimatePresence>
        {activeItem.bgImage && (
          <motion.div
            key={activeItem.bgImage}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.7 }}
            className="absolute inset-0 w-full h-full z-0 scale-110"
            style={{ 
              backgroundImage: `url(${activeItem.bgImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              filter: 'blur(4px)' // Adjust this pixel value to change the blur amount
            }}
          />
        )}
      </AnimatePresence>

      <CardNav
        logo="https://i.postimg.cc/L4t1V7yt/logo-(1).png"
        logoAlt="Company Logo"
        items={t.nav}
        baseColor="#fff"
        menuColor="#000"
        buttonBgColor="#111"
        buttonTextColor="#fff"
        ease="power3.out"
        ctaText={t.cta}
        onLanguageToggle={toggleLanguage}
        lang={lang}
      />
      <div className="flex-1 flex flex-col items-start justify-center text-white p-8 md:p-16 z-10 relative" ref={containerRef}>
        <div className="max-w-xl md:max-w-4xl mt-24 md:mt-0 flex flex-col gap-6">
          <div className="overflow-hidden">
            <h1 className={`reveal-text text-4xl md:text-[7.5rem] md:leading-none font-bold tracking-tight m-0 ${lang === 'am' ? 'font-amharic-bold' : ''}`}>{displayItem.text}</h1>
          </div>
          <div className="overflow-hidden">
            <p className={`reveal-text text-lg md:text-[2.5rem] md:leading-tight text-gray-300 m-0 ${lang === 'am' ? 'font-amharic-light' : ''}`}>
              {displayItem.description}
            </p>
          </div>
        </div>
      </div>
      <div className="w-full md:w-[400px] lg:w-[500px] h-[50vh] md:h-screen relative shrink-0 z-10">
        <CircularGallery 
          items={t.gallery}
          bend={-3} 
          textColor="#ffffff" 
          borderRadius={0.05} 
          scrollSpeed={2}
          scrollEase={0.05}
          onActiveIndexChange={setActiveIndex}
          font={lang === 'am' ? '30px bela-bold' : 'bold 30px Figtree'}
        />
      </div>
    </motion.div>
  );
}
